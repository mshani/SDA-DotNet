﻿using Devices.Interfaces;

namespace Devices
{
    internal class SamsungPhone : IMobile
    {
        public void ConnectToInternet()
        {
            Console.WriteLine("Connecting to internet");
        }

        public void DisconenctInternet()
        {
            Console.WriteLine("Disconnecting internet");
        }

        public void InsertSim()
        {
            Console.WriteLine("Sim inserted");
        }

        public void InstalApp(string appName)
        {
            Console.WriteLine("Installing app :" + appName);
        }

        public void StartCharging()
        {
            Console.WriteLine("Start charging... ");
        }

        public void StopCharging()
        {
            Console.WriteLine("Stopped charging");
        }

        public void SwitchOff()
        {
            Console.WriteLine("Switching off...");
        }

        public void SwitchOn()
        {
            Console.WriteLine("Switching on...");
        }

        public void TurnOffVolume()
        {
            Console.WriteLine("Volume down...");
        }

        public void TurnOnVolume()
        {
            Console.WriteLine("Volume up...");
        }

        public void UnInstalApp(string appName)
        {
            Console.WriteLine("Removing app: " + appName);
        }
    }
}
