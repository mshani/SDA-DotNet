﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookExample
{
    internal class Roman: Libri
    {
        public int NrKapitujsh { get; set; }
        public string Zhaneri { get; set; }
    }
}
