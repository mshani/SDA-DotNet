﻿using StudentTeacherExample;

StudentTeacherTest example = new StudentTeacherTest();
example.Execute();