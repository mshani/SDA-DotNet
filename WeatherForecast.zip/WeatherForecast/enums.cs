﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherForecast
{
    public enum WeatherEnum
    {
        Clear =  1,
        Cloudy = 2,
        Rainy = 3,
        Sunny = 4,
        CoudyAndSunny = 5, 
        Snow = 6,
        Storm = 7,
    }
}
